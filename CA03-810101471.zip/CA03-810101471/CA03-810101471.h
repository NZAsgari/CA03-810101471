#include <stdio.h>
#include <stdlib.h>
typedef struct post Post;
typedef struct user User;
typedef struct like_user Like;
Like* search_like(Like* head, char* string);
char* itoa_num(int num);
void accounts_write(User* head );
char* get_string();
int search_login_signup( char* string );
int search_user(User* head , char* string);
void add_user(User* head , char* string_1 , char* string_2);
int search_login(User* head, char* string_1 , char* string_2);
int* posting (User* head , char* string_1 , char* string_2);
char* get_text();
int atoi_postID(char* string);
int like(User* head , char* string , int ID);
void print_info(User* head , char* string);
int delete_post(User* head , char* string , int ID);
int compare(char* string_1 , char* string_2);
User* search(User* head, char* string);
void copy(char* string_1 , char* string_2);
Post* search_ID(Post* head_post , int ID);
void printing_text(char* text);
void find_user(User* head , char* string);
int search_order(char* string);
// defining the posts : 
// every user has a post pointer 
typedef struct post
{
    char* text;
    int post_ID;
    int like;
    Like* username;    
    Post* next;

}Post;
// defining the users:
// a linked list of users which contains their :
// username
// password
// number of post 
// header of a linked list which point to the posts of this user
typedef struct user
{
    char* username;
    char* password;
    int num_post;
    Post* posts;
    User* next;
}User;
// a linked list of users which liked a post
// the header of this has called in every post struct
typedef struct like_user
{
    char* username;
    Like* next;
}Like;
// geting the strings from buffer
char* get_string()
{
    char* string;
    string=(char*)malloc(sizeof(char)*10);
    if(string==NULL)
    {
        printf("not enough memory\n");
        fflush(stdin);
        return NULL;
    }
    char c;
    int i=0 , size=10;
    c=getchar();
    //countinue getting char from buffer until space or enter
    while(c!='\n'&&c!=' ')
    {
        *(string+i)=c;
        i++;
        if(i>=size)
        {
            // if not having enough memory adding more with realloc
            size+=10;
            string=(char*)realloc(string,size);
            if(string==NULL)
            {
                printf("not enough memory\n");
                fflush(stdin);
                return NULL;
            }
            *(string+i)=c;
        }
        c=getchar();
    }
    *(string+i)='\0';
    return string;
    
}
// finding the order using geting string & comparing it with the defined orders
int search_login_signup( char* string )
{
    char string_2[]="login";
    int returning=0;
    returning = compare(string_2,string);
    if(returning==1)
        return 2;
    char string_3[]="signup";
    returning= compare(string_3,string);
    if(returning==1)
        return 1;
    return 0;
}
// searching if a username is defined or not
int search_user(User* head , char* string)
{
    User* user= search (head , string);
    if(user==0)
        return 0;
    return 1;
}
// add a user after checking the conditions 
void add_user(User* head , char* string_1 , char* string_2)
{
    User* user = head;
    // going to the last node
    while(user->next!= NULL)
        user=user->next;
    // adding datas in user list
    user->next=(User*) malloc(sizeof(User));
    user=user->next;
    user->username=(char*)malloc(sizeof(string_1));
    copy(user->username,string_1);
    user->password=(char*)malloc(sizeof(string_2));
    copy(user->password,string_2);
    user->next=NULL;
    user->num_post=0;
    user->posts=(Post*)malloc(sizeof(Post));
    user->posts->next=NULL;
    user->posts->post_ID=0;
    user->posts->username=(Like*)malloc(sizeof(Like));
    user->posts->username->next=NULL;
    printf("you has signup sucessfully!\n");
}
// searching if a username is in the users linked list or not
// if yes comparing it password with which one in the buffer
int search_login(User* head, char* string_1 , char* string_2)
{
    User* user= search (head , string_1);
    int returning=0;
    if(user==NULL)
        return 0;
    returning = compare (user->password , string_2);
    if(returning==0)
        return 0;
    return 1;
}
// adding a post
int* posting (User* head , char* string_1 , char* string_2)
{
    if(string_2==NULL)
        return NULL;
    //finding user in the linked list
    User* user= search(head , string_1);
    user->num_post++;
    // adding information of the post
    Post* post=user->posts;
    while(post->next!=NULL)
        post=post->next;
    post->next=(Post*) malloc( sizeof(Post));
    post->next->post_ID=post->post_ID+1;
    post=post->next;
    post->text=(char*) malloc(sizeof(string_2));
    copy(post->text,string_2);
    post->like=0;
    post->next=NULL;
    printf("the post added sucessfully!\n");
}
// getting the text of the post from the buffer
char* get_text()
{
    char* string;
    string=(char*)malloc(sizeof(char)*10);
    if(string==NULL)
    {
        printf("not enough memory\n");
        fflush(stdin);
        return NULL;
    }
    char c;
    int i=0 , size=10;
    c=getchar();
    // it continue getting char until enter(text could countain space)
    while(c!='\n')
    {
        *(string+i)=c;
        i++;
        if(i>=size)
        {
            size+=10;
            string=(char*)realloc(string,size);
            if(string==NULL)
            {
                printf("not enough memory\n");
                fflush(stdin);
                return NULL;
            }
            *(string+i)=c;
        }
        c=getchar();
    }
    *(string+i)='\0';
    
    return string;
}
// because post ID in linked list is an integer we should make the ID in buffer an integer
int atoi_postID(char* string)
{
    int i=0,ID=0;
    char* c;
    c=(string+i);
    while((*c)!='\0')
    {
        ID*=10;
        ID+=*c-48;
        i++;
        *c=*(string+i);
    }
    return ID;
}
// liking a post by users
int like(User* head , char* string , int ID)
{
    User* user= search(head , string);
    // searching if the author of post is defined
    if(user==0)
    {
        printf("this username isn't availabe!\n");
        return 0;
    }
    //searching if the post ID is defined
    Post* post=search_ID(user->posts, ID);
    if(post==NULL)
    {
        printf("this post ID isn't availabe!\n");
        return 0;
    }
    // searching if the user had liked this post before
    Like* likes = (post->username);
    Like* liked= search_like(likes,string);
    if(liked!=NULL)
    {
        printf("you has liked this before\n");
        return 0;
    }
    // adding a new node to linked list of people who liked this post
    while(likes->next!=NULL)
        likes=likes->next;
    likes->next=(Like*)malloc(sizeof(Like));
    likes=likes->next;
    likes->username=(char*)malloc(sizeof(string));
    copy(likes->username,string);
    post->next->like++;
    printf("the post liked sucessfully!\n");
}
// searching if the user had liked this post before
Like* search_like(Like* head, char* string)
{
    Like* user=head->next;

    while(user!=NULL)
    {
        int a=compare(user->username,string);
        if(a!=0)
            return user;
        user=user->next;
    }
    return NULL;
}
// printing the info of person who has loged in
void print_info(User* head , char* string)
{
    User* user=search(head , string);
    printf("username: %s\n",user->username);
    printf("password: %s\n",user->password);
    Post* post=user->posts;
    while(post->next!=NULL)
    {
        if(post->post_ID!=0)
        {
            printf("postID: %d\n",post->post_ID);
            printf("post likes: %d\n", post->like);
            printing_text(post->text);
        }
        post=post->next;
    }
    if(post->post_ID!=0)
    {
        printf("postID: %d\n",post->post_ID);
        printf("post likes: %d\n", post->like);
        printing_text(post->text);
    }
}
// deleting one of the post which the loged in user want
int delete_post(User* head , char* string , int ID)
{

    User* user=search(head , string);
    Post* post=NULL;
    // finding the post ID 
    post= search_ID(user->posts,ID);
    if(post==NULL)
    {
        printf("this post ID isn't availabe!\n");
        return 0;
    }
    //deleting it:)
    Post* a= post->next;
    post->next=post->next->next;
    user->num_post--;
    free(a);
    printf("the post deleted sucessfully!\n");
}
// writing the accounts username, password & number of posts in accounts.txt
void accounts_write(User* head )
{
    FILE* accounts=fopen("accounts.txt","w");
    User* user=head->next;
    while(user!=NULL)
    {
        fwrite(user->username,sizeof(char),sizeof(user->username),accounts);
        fwrite(" ",sizeof(char), 1,accounts);
        fwrite(user->password,sizeof(char),sizeof(user->password),accounts);
        fwrite(" ",sizeof(char), 1,accounts);
        // making the number of posts a string
        char* num= itoa_num(user->num_post);
        fwrite(num,sizeof(char),sizeof(num),accounts);
        fwrite("\n",sizeof(char), 1,accounts);
        free(num);
        user=user->next;
    }
    fclose(accounts);
}
// writing the posts of every users in order
// posts infos include author & like number
void post_write(User* head)
{
    FILE* posts= fopen("posts.txt", "w");
    User* user= head->next;
    while(user!=NULL)
    {
        Post* post = user->posts->next;
        while(post!=NULL)
        {
            int size=0;
            while(*(post->text+size)!='\0')
                size++;
            fwrite(post->text,sizeof(char),size,posts);
            fwrite(" ",sizeof(char), 1,posts);
            fwrite(user->username,sizeof(char),sizeof(user->username),posts);
            fwrite(" ",sizeof(char), 1,posts);
            // making the number of likes a string
            char* num= itoa_num(post->like);
            fwrite(num,sizeof(char),sizeof(num)-1,posts);
            fwrite("\n",sizeof(char), 1, posts);
            free(num);
            post=post->next;
        }
        user=user->next;
    }
    fclose(posts);
}
// making an integer to a string 
char* itoa_num(int num)
{
    int reverse=0 , i=0;
    while(num!=0)
    {
        int remaind=num%10;
        reverse*=10;
        reverse+=remaind;
        num=num/10;
        i++;
    }
    char* c=(char*)malloc(sizeof(char)*(i+1));
    int j=0;
    while(j<i)
    {
        int remaind=reverse%10;
        reverse/=10;
        *(c+j)=remaind+48;
        j++;
    }
    *(c+j)='\0';
    return c;
}
// comparing to string 
int compare(char* string_1 , char* string_2)
{
    int i=0;
    while(*(string_1+i)!='\0')
    {
        if(*(string_1+i)!=*(string_2+i))
            return 0;
        i++;
    }
    // if they were same return 1
    return 1;
}
//searching a username in the linked list of users
User* search(User* head, char* string)
{
    User* user=head->next;

    while(user!=NULL)
    {
        int a=compare(user->username,string);
        if(a!=0)
            return user;
        user=user->next;
    }
    return NULL;
}
// copying a string into the other one
void copy(char* string_1 , char* string_2)
{
    int i=0;
    char c=*(string_2+i);
    while(c!='\0')
    {
        *(string_1+i)=c;
        i++;
        c=*(string_2+i);
    }
    *(string_1+i)='\0';
}
// searching if the ID is defined in posts
Post* search_ID(Post* head_post , int ID)
{
    Post* post= head_post;
    while(post->next!=NULL)
    {
        if(post->next->post_ID==ID)
            return post;
        post=post->next;
    }
    return NULL;
}
//printing the text of posts
void printing_text(char* text)
{
    char c;
    int i=0 ;
    c=*(text);
    // it continue printing until the null char
    while(c!='\0')
    {
        putchar(c);
        i++;
        c=*(text+i);
    }   
    printf("\n");
}
// searching if which of the orders is input
int search_order(char* string)
{
    char string_2[]="post";
    int returning=0;
    returning = compare(string,string_2);
    if(returning==1)
        return 1;
    char string_3[]="like";
    returning= compare(string,string_3);
    if(returning==1)
        return 2;
    char string_4[]="logout";
    returning = compare(string,string_4);
    if(returning==1)
        return 3;
    char string_5[]="delete";
    returning= compare(string,string_5);
    if(returning==1)
        return 4;
    char string_6[]="info";
    returning = compare(string,string_6);
    if(returning==1)
        return 5;
    char string_7[]="find_user";
    returning= compare(string,string_7);
    if(returning==1)
        return 6;
    return 0;
}
// printing the info of a user 
void find_user(User* head , char* string)
{
    User* user=search(head , string);
    printf("username: %s\n",user->username);
    Post* post=user->posts;
    while(post->next!=NULL)
    {
        if(post->post_ID!=0)
        {
            printf("postID: %d\n",post->post_ID);
            printf("post likes: %d\n", post->like);
            printing_text(post->text);
        }
        post=post->next;
    }
    if(post->post_ID!=0)
    {
        printf("postID: %d\n",post->post_ID);
        printf("post likes: %d\n", post->like);
        printing_text(post->text);
    }
}

