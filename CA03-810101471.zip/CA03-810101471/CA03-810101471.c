#include "CA03-810101471.h"
void main()
{
    // initilizing 
    User* head_user=(User*)malloc(sizeof(User));
    head_user->next=NULL;
    int activity=0;
    char* temp_string ;
    char* temp_string_2 ;
    char* temp_string_3;
    // first while----> fist access level
    while(1)
    {
        printf("choose login or signup\n");
        temp_string=get_string();
        if(temp_string==NULL)
            continue;
        activity=search_login_signup(temp_string);
        switch (activity)
        {
        case 0:
            //unknown input
            printf("your order is undefined!\n");
            fflush(stdin);
            continue;
            break;
        case 1:
            //signup
            temp_string=get_string();
            if(temp_string==NULL)
                continue;
            activity=search_user(head_user,temp_string);
            if(activity==1)
            {
                printf("this username has already taken!\n");
                fflush(stdin);
                continue;
            }
            temp_string_2=get_string();
            if(temp_string_2==NULL)
                continue;
            add_user(head_user,temp_string,temp_string_2);
            accounts_write( head_user);
            continue;
            break;
        case 2:
            //login
            temp_string=get_string();
            if(temp_string==NULL)
                continue;
            temp_string_2=get_string();
            if(temp_string_2==NULL)
                continue;
            activity=search_login(head_user,temp_string,temp_string_2);
            if(activity==0)
            {
                printf("your username or password is incorrect!\n");
                fflush(stdin);
                continue;
            }
            printf("you has login as %s\n", temp_string);
            break;
        }
        // second while-----> second access level
        while(1)
        {
            printf("choose what you want to do!\n");
            temp_string_2=get_string();
            if(temp_string_2==NULL)
                continue;
            activity=search_order(temp_string_2);
            // doing the orders
            switch (activity)
            {
            case 0:
                printf("your order is undefined!\n");
                fflush(stdin);
                continue;
                break;
            case 1:
                // adding a post
                temp_string_2=get_text();
                if(temp_string_2==NULL)
                    continue;
                posting(head_user,temp_string,temp_string_2);
                break;
            case 2:
                //liking
                temp_string_2=get_string();
                if(temp_string_2==NULL)
                    continue;
                temp_string_3=get_string();
                if(temp_string_3==NULL)
                    continue;
                int post_ID= atoi_postID(temp_string_3);
                like(head_user,temp_string_2,post_ID);
                break;
            case 3:
                //log out
                printf("you has logout sucessfully!\n");
                break;
            case 4:
                //delete post
                temp_string_2=get_string();
                if(temp_string_2==NULL)
                    continue;
                post_ID=atoi_postID(temp_string_2);
                delete_post(head_user,temp_string,post_ID);
                break;
            case 5:
                //info
                print_info(head_user,temp_string);
                break;
            case 6:
                //find user
                temp_string_2=get_string();
                if(temp_string_2==NULL)
                    continue;
                find_user(head_user,temp_string_2);
                break;
            }
            // writing th txt files
            accounts_write( head_user);
            post_write( head_user);
            //free the strings
            free(temp_string_2);
            free(temp_string_3);
            // Restrict access level
            if(activity==3)
                break;
        }
    }
}